import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import { UserService } from '../user.service';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx'; // untuk camera

@Component({
  selector: 'app-editprofile',
  templateUrl: './editprofile.component.html',
  styleUrls: ['./editprofile.component.scss'],
})
export class EditprofileComponent implements OnInit {
  username: string = "";
  password: string = "";
  name: string = "";
  email: string = "";
  bio: string = "";
  image: string = "";
  passwordType: string = 'password';
  passwordIcon: string = 'eye';
  options: CameraOptions = {
    quality: 100,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    sourceType: this.camera.PictureSourceType.CAMERA,
    saveToPhotoAlbum: true
  };
  constructor(private userService: UserService, private app: AppComponent, public camera:Camera) { }

  ngOnInit() {
    this.getProfile();
  }

  hideShowPassword() {
    if(this.passwordType == "password") {
      this.passwordType = "text";
      this.passwordIcon = "eye-off";
    } else {
      this.passwordType = "password";
      this.passwordIcon = "eye";
    }
  }

  ambilFoto() {
    this.camera.getPicture(this.options).then(
      (imageData) => {
         let base64Image = 'data:image/jpeg;base64,' + imageData;
         this.image = base64Image;
      }
      , (err) => {
        // kalau error
      }
     );
  }

  getProfile() {
    this.userService.getProfile(localStorage.getItem('username')).subscribe(
      (data) => { 
        if (data['result'] == 'success') {
          this.username = data['data']['username'];
          this.password = data['data']['password'];
          this.name = data['data']['name']; 
          this.email = data['data']['email']; 
          this.bio = data['data']['bio']; 
          this.image = data['data']['image'];
        } 
      }
    );
  }

  editProfile() {
    var status = 0;
    if(this.image != this.username + ".jpg") {
      status = 1;
    }
    this.userService.editProfile(this.username, this.password, this.name, this.email, this.bio, this.image, status).subscribe(
      (data) => { 
        this.app.showToast(data['result']);
      }
    );
  }
}
