import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppComponent } from '../app.component';
import { PostService } from '../post.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent implements OnInit {
  username: string = "";
  name: string = "";
  email: string = "";
  bio: string = "";
  // untuk post
  posts = [];
  status = [];
  likes = [];
  existPost:boolean = false;

  constructor(private route: ActivatedRoute, private userService: UserService, private post: PostService, private app: AppComponent) { }

  ngOnInit() {
    this.username = this.route.snapshot.params['username'];
    this.getProfile();
    this.listPost();
  }

  getProfile() {
    this.userService.getProfile(this.username).subscribe(
      (data) => { 
        if (data['result'] == 'success') {
          this.name = data['data']['name']; 
          this.email = data['data']['email']; 
          this.bio = data['data']['bio']; 
        } 
      }
    );
  }

  listPost() {
    this.post.specificPostList(localStorage.getItem('username')).subscribe(
      (data) => { 
        this.posts = data; 
        if(this.posts.length > 0) {
          this.existPost = true;
        }
        
        this.posts.forEach(element => {
          this.status[element['id']] = element['status'];
          this.likes[element['id']] = element['like'];
        });
      }
    );
  }

  likeClicked(id: number, status: number) {
    if(status == 0) {
      this.post.addLike(localStorage.getItem('username'), id).subscribe(
        (data) => { 
          if (data['result'] == 'success') {
            this.status[id] = 1;
            this.likes[id] += 1
          } else {
            this.app.showToast("Connection error!");
          }
        }
      );
    } else {
      this.post.removeLike(localStorage.getItem('username'), id).subscribe(
        (data) => { 
          if (data['result'] == 'success') {
            this.status[id] = 0;
            this.likes[id] -= 1;
          } else {
            this.app.showToast("Connection error!");
          }
        }
      );
    }
  }
}
