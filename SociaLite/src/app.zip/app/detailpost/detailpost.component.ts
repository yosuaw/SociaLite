import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import { ActivatedRoute } from '@angular/router';
import { PostService } from '../post.service';

@Component({
  selector: 'app-detailpost',
  templateUrl: './detailpost.component.html',
  styleUrls: ['./detailpost.component.scss'],
})
export class DetailpostComponent implements OnInit {
  id:number = 0;
  title:string = "";
  caption:string = "";
  imgUrl:string = "";
  date:string = "";
  username:string = "";
  likes:number = 0;
  status:number = 0;
  comments = [];
  profileUrl:string = "";
  newcomment:string = "";
  newreply:string = "";
  replyStatus = [];

  constructor(public app: AppComponent, public ps: PostService, public route: ActivatedRoute) { }

  ngOnInit() {
    this.id = parseInt(this.route.snapshot.params['id']);
    this.ps.loadDetailPost(localStorage.getItem('username'), this.id).subscribe(
      (data) => { 
        this.title = data[0]["title"];
        this.caption = data[0]["caption"];
        this.imgUrl = data[0]["image"];
        this.date = data[0]["date"];
        this.username = data[0]["username"];
        this.status = data[0]["status"];
        this.likes = data[0]["like"];
      }
    );
    this.loadComment();

    this.comments.forEach(element => {
      this.replyStatus.push(0);
    });
  }

  likeClicked(id: number, status: number) {
    if(status == 0) {
      this.ps.addLike(localStorage.getItem('username'), id).subscribe(
        (data) => { 
          if (data['result'] == 'success') {
            this.status = 1;
            this.likes += 1;
          } else {
            this.app.showToast("Connection error!");
          }
        }
      );
    } else {
      this.ps.removeLike(localStorage.getItem('username'), id).subscribe(
        (data) => { 
          if (data['result'] == 'success') {
            this.status = 0;
            this.likes -= 1;
          } else {
            this.app.showToast("Connection error!");
          }
        }
      );
    }
  }

  loadComment() {
    this.ps.loadComment(localStorage.getItem('username'), this.id).subscribe(
      (data) => { 
        this.comments = data;
      }
    );
  }

  addComment() {
    this.ps.addComment(this.id, this.newcomment, localStorage.getItem('username')).subscribe(
      (data) => {
        this.ps.loadComment(localStorage.getItem('username'), this.id).subscribe(
          (data) => { 
            this.comments.push(data[data.length-1]);
          }
        );
      }
    )
  }

  addReply(idcomment:number) {
    this.ps.addReply(idcomment, this.newreply, localStorage.getItem('username')).subscribe(
      (data) => {
        this.ps.loadComment(localStorage.getItem('username'), this.id).subscribe(
          (data) => { 
            this.comments[idcomment]['reply'].push(data[idcomment]['reply']);
          }
        ); 
      }
    )
  }

  replyComment(index:number) {
    if (this.replyStatus[index] == 1)
      this.replyStatus[index] = 0;
    else
      this.replyStatus[index] = 1;
  }

}
